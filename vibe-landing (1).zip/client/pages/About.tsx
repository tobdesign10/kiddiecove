import Header from "../components/Header";

export default function About() {
  return (
    <div className="min-h-screen bg-white">
      <Header currentPage="about" />

      {/* Hero Section */}
      <section className="bg-kiddie-blue px-4 py-12 lg:py-20">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="space-y-6">
              <h1
                className="text-5xl md:text-6xl lg:text-7xl font-normal text-black"
                style={{ fontFamily: "'Just Another Hand', cursive" }}
              >
                About KiddieCove
              </h1>
              <p className="text-xl lg:text-2xl text-black font-medium leading-relaxed">
                Where every child's journey begins with love, learning, and
                endless possibilities.
              </p>
              <p className="text-lg lg:text-xl text-black font-normal leading-relaxed">
                At KiddieCove, we believe that early childhood is the foundation
                for a lifetime of learning. Our nurturing environment encourages
                children to explore, discover, and grow while building
                confidence and developing essential skills for their future.
              </p>
            </div>
            <div className="flex justify-center lg:justify-end">
              <img
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/827a6bd8987ee2d465f7823c0daac7411435786e?width=1526"
                alt="Happy children at KiddieCove"
                className="w-full max-w-md lg:max-w-lg xl:max-w-xl rounded-2xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Mission Section */}
      <section className="bg-kiddie-cream px-4 py-12 lg:py-20">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2
              className="text-4xl md:text-5xl lg:text-6xl font-normal text-black mb-6"
              style={{ fontFamily: "'Just Another Hand', cursive" }}
            >
              Our Mission
            </h2>
            <p className="text-lg lg:text-xl text-black font-normal max-w-4xl mx-auto leading-relaxed">
              To provide a safe, nurturing, and stimulating environment where
              children can explore, learn, and develop their unique talents
              while building strong foundations for lifelong learning.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Value 1 */}
            <div className="bg-kiddie-card rounded-2xl p-6 text-center shadow-sm">
              <div className="w-16 h-16 bg-kiddie-orange rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  className="w-8 h-8 text-white"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                </svg>
              </div>
              <h3 className="text-xl lg:text-2xl font-medium text-black mb-3">
                Safe & Secure
              </h3>
              <p className="text-base lg:text-lg text-black font-normal">
                Your child's safety is our top priority. We maintain strict
                safety protocols and a secure environment where children can
                explore with confidence.
              </p>
            </div>

            {/* Value 2 */}
            <div className="bg-kiddie-card rounded-2xl p-6 text-center shadow-sm">
              <div className="w-16 h-16 bg-kiddie-coral rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  className="w-8 h-8 text-white"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                </svg>
              </div>
              <h3 className="text-xl lg:text-2xl font-medium text-black mb-3">
                Expert Care
              </h3>
              <p className="text-base lg:text-lg text-black font-normal">
                Our qualified and experienced educators are passionate about
                early childhood development and dedicated to nurturing each
                child's unique potential.
              </p>
            </div>

            {/* Value 3 */}
            <div className="bg-kiddie-card rounded-2xl p-6 text-center shadow-sm">
              <div className="w-16 h-16 bg-kiddie-green rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  className="w-8 h-8 text-white"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" />
                </svg>
              </div>
              <h3 className="text-xl lg:text-2xl font-medium text-black mb-3">
                Individual Focus
              </h3>
              <p className="text-base lg:text-lg text-black font-normal">
                We recognize that every child is unique. Our individualized
                approach ensures each child receives the attention and support
                they need to thrive.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="bg-white px-4 py-12 lg:py-20">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center">
            <div className="order-2 lg:order-1">
              <img
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/8870b2e6ae3234aa121cf0d50d0f34ecd264d1b9?width=800"
                alt="Children learning together at KiddieCove"
                className="w-full rounded-2xl shadow-lg"
              />
            </div>
            <div className="order-1 lg:order-2 space-y-6">
              <h2
                className="text-4xl md:text-5xl lg:text-6xl font-normal text-black"
                style={{ fontFamily: "'Just Another Hand', cursive" }}
              >
                Our Story
              </h2>
              <p className="text-lg lg:text-xl text-black font-normal leading-relaxed">
                Founded in 2015, KiddieCove began as a small family-owned center
                with a big dream: to create a place where children could learn,
                grow, and discover the joy of learning in a loving, supportive
                environment.
              </p>
              <p className="text-lg lg:text-xl text-black font-normal leading-relaxed">
                Today, we proudly serve families in the Brantford community,
                providing exceptional early childhood education and care for
                children aged 18 months to 5 years. Our experienced team of
                educators brings passion, expertise, and genuine care to every
                interaction with your child.
              </p>
              <p className="text-lg lg:text-xl text-black font-normal leading-relaxed">
                We believe that the early years are the most important in a
                child's development, and we're honored to be part of your
                child's journey toward becoming confident, curious, and capable
                learners.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="bg-kiddie-cream px-4 py-12 lg:py-20">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2
              className="text-4xl md:text-5xl lg:text-6xl font-normal text-black mb-6"
              style={{ fontFamily: "'Just Another Hand', cursive" }}
            >
              Why Choose KiddieCove?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-kiddie-orange rounded-full flex-shrink-0 mt-1"></div>
                <div>
                  <h3 className="text-xl lg:text-2xl font-medium text-black mb-2">
                    Low Student-to-Teacher Ratios
                  </h3>
                  <p className="text-base lg:text-lg text-black font-normal">
                    We maintain small class sizes to ensure personalized
                    attention for every child.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-kiddie-coral rounded-full flex-shrink-0 mt-1"></div>
                <div>
                  <h3 className="text-xl lg:text-2xl font-medium text-black mb-2">
                    Play-Based Learning
                  </h3>
                  <p className="text-base lg:text-lg text-black font-normal">
                    Our curriculum integrates play with learning to make
                    education fun and engaging.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-kiddie-green rounded-full flex-shrink-0 mt-1"></div>
                <div>
                  <h3 className="text-xl lg:text-2xl font-medium text-black mb-2">
                    Nutritious Meals
                  </h3>
                  <p className="text-base lg:text-lg text-black font-normal">
                    We provide healthy, balanced meals and snacks prepared fresh
                    daily.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-kiddie-orange rounded-full flex-shrink-0 mt-1"></div>
                <div>
                  <h3 className="text-xl lg:text-2xl font-medium text-black mb-2">
                    Extended Hours
                  </h3>
                  <p className="text-base lg:text-lg text-black font-normal">
                    Flexible schedules to accommodate working families' needs.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-kiddie-coral rounded-full flex-shrink-0 mt-1"></div>
                <div>
                  <h3 className="text-xl lg:text-2xl font-medium text-black mb-2">
                    Regular Updates
                  </h3>
                  <p className="text-base lg:text-lg text-black font-normal">
                    Daily reports and photos keep you connected to your child's
                    day.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-6 h-6 bg-kiddie-green rounded-full flex-shrink-0 mt-1"></div>
                <div>
                  <h3 className="text-xl lg:text-2xl font-medium text-black mb-2">
                    Parent Partnership
                  </h3>
                  <p className="text-base lg:text-lg text-black font-normal">
                    We work closely with families to support each child's
                    development.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-kiddie-blue px-4 py-12 lg:py-16">
        <div className="container mx-auto text-center">
          <h2
            className="text-4xl md:text-5xl lg:text-6xl font-normal text-black mb-6"
            style={{ fontFamily: "'Just Another Hand', cursive" }}
          >
            Ready to Join Our Family?
          </h2>
          <p className="text-lg lg:text-xl text-black font-normal mb-8 max-w-2xl mx-auto">
            We'd love to welcome your child to the KiddieCove family. Schedule a
            tour today and see why parents choose us for their children's early
            learning journey.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-kiddie-orange text-white px-8 py-3 rounded-lg text-xl font-medium hover:opacity-90 transition-opacity border-2 border-red-300">
              Schedule a Tour
            </button>
            <button className="bg-kiddie-dark text-white px-8 py-3 rounded-lg text-xl font-medium hover:opacity-90 transition-opacity border-2 border-gray-800">
              Contact Us
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
