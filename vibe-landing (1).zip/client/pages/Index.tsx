import Header from "../components/Header";

export default function Index() {
  return (
    <div className="min-h-screen bg-white">
      <Header currentPage="home" />

      {/* Hero Section */}
      <section className="bg-kiddie-blue px-4 py-8 lg:py-16">
        <div className="container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div className="space-y-6 lg:space-y-8">
            <h1
              className="text-4xl md:text-5xl lg:text-6xl font-normal text-black"
              style={{ fontFamily: "'Just Another Hand', cursive" }}
            >
              WELCOME TO KIDDICOVE!
            </h1>

            <p className="text-lg md:text-xl lg:text-2xl text-black font-medium max-w-lg">
              A warm and Trusted Early Childhood Center where Children Learn,
              Play and Grow.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-kiddie-orange text-white px-8 py-3 rounded-lg text-xl font-medium hover:opacity-90 transition-opacity border-2 border-red-300">
                Schedule a Tour
              </button>
              <button className="bg-kiddie-dark text-white px-8 py-3 rounded-lg text-xl font-medium hover:opacity-90 transition-opacity border-2 border-gray-800">
                Explore
              </button>
            </div>
          </div>

          <div className="flex justify-center lg:justify-end">
            <img
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/827a6bd8987ee2d465f7823c0daac7411435786e?width=1526"
              alt="Happy children learning at KiddieCove"
              className="w-full max-w-md lg:max-w-lg xl:max-w-xl rounded-lg"
            />
          </div>
        </div>
      </section>

      {/* Featured Programs */}
      <section className="bg-kiddie-cream px-4 py-12 lg:py-20">
        <div className="container mx-auto">
          <h2
            className="text-5xl md:text-6xl lg:text-8xl font-normal text-black text-center mb-8 lg:mb-16"
            style={{ fontFamily: "'Just Another Hand', cursive" }}
          >
            featured Programs
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mb-8">
            {/* Toddlers */}
            <div className="bg-kiddie-card rounded-3xl p-6 shadow-sm">
              <div className="text-center mb-6">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/0c8d3db760f2741c30d5852a86c9a3cfa228efa9?width=632"
                  alt="Toddlers Program"
                  className="w-48 h-48 mx-auto object-cover rounded-2xl mb-4"
                />
                <h3 className="text-2xl lg:text-3xl font-medium text-black mb-2">
                  Toddlers
                </h3>
                <p className="text-2xl lg:text-3xl text-black font-normal">
                  Explore, play, grow, discover, smile.
                </p>
              </div>
              <div className="text-center">
                <button className="bg-kiddie-coral text-black px-6 py-3 rounded-lg text-base font-medium hover:opacity-90 transition-opacity border border-gray-800">
                  Learn More
                </button>
              </div>
            </div>

            {/* Pre-School */}
            <div className="bg-kiddie-card rounded-3xl p-6 shadow-sm">
              <div className="text-center mb-6">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/a77aef7b323f35c7284283a6035139cba8c3e5b0?width=552"
                  alt="Pre-School Program"
                  className="w-48 h-48 mx-auto object-cover rounded-2xl mb-4"
                />
                <h3 className="text-2xl lg:text-3xl font-medium text-black mb-2">
                  Pre-School
                </h3>
                <p className="text-2xl lg:text-3xl text-black font-normal">
                  Confidence, creativity, learning through play.
                </p>
              </div>
              <div className="text-center">
                <button className="bg-kiddie-coral text-black px-6 py-3 rounded-lg text-base font-medium hover:opacity-90 transition-opacity border border-gray-800">
                  Learn More
                </button>
              </div>
            </div>

            {/* Pre-Kindergarten */}
            <div className="bg-kiddie-card rounded-3xl p-6 shadow-sm">
              <div className="text-center mb-6">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/0a0d896905463a56a18d49b9eacfb8c9376a032a?width=710"
                  alt="Pre-Kindergarten Program"
                  className="w-48 h-48 mx-auto object-cover rounded-2xl mb-4"
                />
                <h3 className="text-2xl lg:text-3xl font-medium text-black mb-2">
                  Pre-Kindergarten
                </h3>
                <p className="text-2xl lg:text-3xl text-black font-normal">
                  Ready for school with fun.
                </p>
              </div>
              <div className="text-center">
                <button className="bg-kiddie-coral text-black px-6 py-3 rounded-lg text-base font-medium hover:opacity-90 transition-opacity border border-gray-800">
                  Learn More
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-kiddie-cream px-4 py-12 lg:py-20">
        <div className="container mx-auto">
          <h2
            className="text-5xl md:text-6xl lg:text-8xl font-normal text-black text-center mb-8 lg:mb-16"
            style={{ fontFamily: "'Just Another Hand', cursive" }}
          >
            Testimonials
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            {/* Testimonial 1 */}
            <div className="bg-kiddie-green border-2 border-black opacity-50 p-6 rounded-lg">
              <p
                className="text-lg lg:text-2xl text-black font-normal leading-tight"
                style={{ letterSpacing: "3px" }}
              >
                KiddieCove made my daughter feel safe, happy, and excited to
                learn every day. We love the warm staff! — Jessica M.
              </p>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-kiddie-green border-2 border-black opacity-50 p-6 rounded-lg">
              <p
                className="text-lg lg:text-2xl text-black font-normal leading-tight"
                style={{ letterSpacing: "3px" }}
              >
                The teachers are amazing! My son always comes home with a smile
                and new things to share. — Daniel A.
              </p>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-green-100 border border-gray-300 p-6 rounded-lg shadow-lg">
              <p
                className="text-lg lg:text-2xl text-black font-normal leading-tight"
                style={{ letterSpacing: "3px" }}
              >
                From day one, KiddieCove felt like family. It's more than a
                school—it's a nurturing, joyful place. — Linda O.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Photo Gallery */}
      <section className="bg-kiddie-cream px-4 py-12 lg:py-20">
        <div className="container mx-auto">
          <h2
            className="text-5xl md:text-6xl lg:text-8xl font-normal text-black text-center mb-6"
            style={{ fontFamily: "'Just Another Hand', cursive" }}
          >
            Photo Gallery
          </h2>

          <div className="text-center mb-12">
            <h3 className="text-2xl lg:text-3xl text-black font-normal mb-4">
              Peek Into Our World
            </h3>
            <p className="text-lg lg:text-2xl text-black font-normal max-w-4xl mx-auto">
              Explore joyful moments from our classrooms, playground, and
              events. Our gallery captures the laughter, learning, and love at
              KiddieCove.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            <img
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/8870b2e6ae3234aa121cf0d50d0f34ecd264d1b9?width=800"
              alt="Children learning in classroom"
              className="w-full h-64 md:h-80 object-cover rounded-lg"
            />
            <img
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/d65b59399f62f9a2c65b8222aece0666f630c19a?width=800"
              alt="Child playing outdoors"
              className="w-full h-64 md:h-80 object-cover rounded-lg"
            />
            <img
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/1614cf7194080af3e5948f98af5f1a6986cf644c?width=800"
              alt="Children doing arts and crafts"
              className="w-full h-64 md:h-80 object-cover rounded-lg"
            />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-kiddie-cream px-4 py-12 lg:py-20">
        <div className="container mx-auto">
          <h2
            className="text-5xl md:text-6xl lg:text-8xl font-normal text-black text-center mb-12"
            style={{ fontFamily: "'Just Another Hand', cursive" }}
          >
            FOOTER
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {/* Logo and Address */}
            <div className="space-y-6">
              <img
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/ffcbd4b12517e780f56afd3cdd3de40edd5fb30c?width=622"
                alt="KiddieCove Logo"
                className="w-32 h-32"
              />
              <div>
                <h3 className="text-2xl lg:text-3xl text-black font-normal mb-4">
                  Address
                </h3>
                <p className="text-lg lg:text-2xl text-black font-normal">
                  KiddieCove Early Learning Center
                  <br />
                  123 Sunny Lane
                  <br />
                  Brantford, ON N3T 2A1
                  <br />
                  Canada
                </p>
              </div>
            </div>

            {/* Quick Links */}
            <div className="md:col-span-1 lg:col-span-1">
              <h3 className="text-2xl lg:text-3xl text-black font-normal mb-6">
                Quick Links
              </h3>
              <ul className="space-y-3">
                <li>
                  <a
                    href="/"
                    className="text-lg lg:text-2xl text-black font-normal hover:opacity-70 transition-opacity"
                  >
                    Home
                  </a>
                </li>
                <li>
                  <a
                    href="/about"
                    className="text-lg lg:text-2xl text-black font-normal hover:opacity-70 transition-opacity"
                  >
                    About Us
                  </a>
                </li>
                <li>
                  <a
                    href="/programs"
                    className="text-lg lg:text-2xl text-black font-normal hover:opacity-70 transition-opacity"
                  >
                    Programs
                  </a>
                </li>
                <li>
                  <a
                    href="/team"
                    className="text-lg lg:text-2xl text-black font-normal hover:opacity-70 transition-opacity"
                  >
                    Our Team
                  </a>
                </li>
                <li>
                  <a
                    href="/gallery"
                    className="text-lg lg:text-2xl text-black font-normal hover:opacity-70 transition-opacity"
                  >
                    Gallery
                  </a>
                </li>
                <li>
                  <a
                    href="/testimonials"
                    className="text-lg lg:text-2xl text-black font-normal hover:opacity-70 transition-opacity"
                  >
                    Testimonials
                  </a>
                </li>
                <li>
                  <a
                    href="/contact"
                    className="text-lg lg:text-2xl text-black font-normal hover:opacity-70 transition-opacity"
                  >
                    Contact Us
                  </a>
                </li>
              </ul>
            </div>

            {/* Social Media */}
            <div className="flex flex-col items-start lg:items-end space-y-4">
              <div className="flex space-x-4">
                <img
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/0b2a5500aaeb8f71c49dee3ff4f40c2ef5ca122d?width=180"
                  alt="LinkedIn"
                  className="w-12 h-12 hover:opacity-70 transition-opacity cursor-pointer"
                />
                <img
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/aa7d35585bd4a6a0c8431e1a48671efc0c954f1e?width=180"
                  alt="Instagram"
                  className="w-12 h-12 hover:opacity-70 transition-opacity cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Copyright */}
          <div className="border-t border-gray-300 pt-8 text-center">
            <div className="flex items-center justify-center space-x-4">
              <img
                src="https://cdn.builder.io/api/v1/image/assets/TEMP/2ca0fc6bd75c545b5b73537513d42adebb9d01d2?width=180"
                alt="Copyright"
                className="w-8 h-8"
              />
              <p className="text-lg lg:text-2xl text-black font-normal">
                Copyright 2025, Kiddiecove
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
