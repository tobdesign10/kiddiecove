interface HeaderProps {
  currentPage?: string;
}

export default function Header({ currentPage = "home" }: HeaderProps) {
  const navItems = [
    { name: "Home", href: "/", key: "home" },
    { name: "About Us", href: "/about", key: "about" },
    { name: "Programs", href: "/programs", key: "programs" },
    { name: "Our Team", href: "/team", key: "team" },
    { name: "Gallery", href: "/gallery", key: "gallery" },
    { name: "Testimonials", href: "/testimonials", key: "testimonials" },
  ];

  return (
    <header className="bg-kiddie-blue px-4 py-6">
      <div className="container mx-auto flex items-center justify-between">
        {/* Logo */}
        <div className="flex-shrink-0">
          <a href="/">
            <img
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/dd650f5ba58252f432407a25b201bc313d44def4?width=622"
              alt="KiddieCove Logo"
              className="w-20 h-20 md:w-24 md:h-24 lg:w-32 lg:h-32"
            />
          </a>
        </div>

        {/* Navigation */}
        <nav className="hidden md:flex space-x-6 lg:space-x-9">
          {navItems.map((item) => (
            <a
              key={item.key}
              href={item.href}
              className={`text-black text-lg lg:text-2xl font-medium hover:opacity-70 transition-opacity ${
                currentPage === item.key ? "underline" : ""
              }`}
            >
              {item.name}
            </a>
          ))}
        </nav>

        {/* Mobile Menu Button */}
        <button className="md:hidden p-2">
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 6h16M4 12h16M4 18h16"
            />
          </svg>
        </button>
      </div>
    </header>
  );
}
